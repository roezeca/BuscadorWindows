"""Texto Unicode válido para SQLite y Qt, sin alterar rutas de archivos."""

import re

_SURROGATE = re.compile(r"[\ud800-\udfff]")


def clean_text(value: str) -> str:
    """Une pares UTF-16 válidos y reemplaza unidades aisladas por U+FFFD.

    Un lector PDF puede devolver sustitutos UTF-16 dentro de un str de Python.
    No se aplica a identidades de archivos: dos rutas distintas no deben
    convertirse en la misma ruta por reemplazar caracteres.
    """
    if not _SURROGATE.search(value):
        return value
    return value.encode("utf-16-le", errors="surrogatepass").decode("utf-16-le", errors="replace")


def escaped_text(value: str) -> str:
    """Representa nombres ilegibles en el registro sin perder su diagnóstico."""
    return value.encode("utf-8", errors="backslashreplace").decode("utf-8")


def require_valid_path(value: str) -> str:
    try:
        value.encode("utf-8")
    except UnicodeEncodeError as error:
        raise ValueError("La ruta contiene caracteres Unicode inválidos. Elige su carpeta contenedora o renombra esa ubicación.") from error
    return value
