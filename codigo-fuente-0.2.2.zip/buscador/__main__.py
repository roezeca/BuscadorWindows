if __name__ == "__main__":
    from multiprocessing import freeze_support
    freeze_support()
    from buscador.app import main
    main()
